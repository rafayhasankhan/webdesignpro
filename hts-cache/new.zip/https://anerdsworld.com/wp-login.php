<!DOCTYPE html>
	<html lang="en-US">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; A Nerd&#039;s World &#8212; WordPress</title>
	<meta name='robots' content='max-image-preview:large, noindex, noarchive' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel='stylesheet' id='dashicons-css'  href='https://anerdsworld.com/wp-includes/css/dashicons.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='https://anerdsworld.com/wp-includes/css/buttons.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css'  href='https://anerdsworld.com/wp-admin/css/forms.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css'  href='https://anerdsworld.com/wp-admin/css/l10n.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='https://anerdsworld.com/wp-admin/css/login.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='logincust_styles-css'  href='https://anerdsworld.com/wp-content/plugins/login-customizer/src/Customizer/Panel/Assets/CSS/customizer.css' type='text/css' media='all' />
<style id='logincust_styles-inline-css' type='text/css'>
body.login {background-image: url(" https://anerdsworld.com/wp-content/uploads/2021/04/seo-course-header-1.jpg ");background-color: #ff9900;background-size: cover;}body.login div#login h1 a {background-image: url(" https://anerdsworld.com/wp-content/uploads/2019/12/nerd_logo_new_white-1-e1591382881547.png ");width: 125px;height: 60px;background-size: 125px 60px;padding-bottom: 0px;}#login form#loginform, #login form#registerform, #login form#lostpasswordform {background-color: #ffffff;padding: 26px 24px 46px 25px;border-radius: 10px;box-shadow: 0 1px 50px rgba(2,2,2,0.3);}#login form#loginform .input, #login form#registerform .input, #login form#lostpasswordform .input {border-width: 0px;box-shadow: unset;}#login form#loginform label, #login form#registerform label, #login form#lostpasswordform label {}#login form#loginform .forgetmenot label, #login form#registerform .forgetmenot label, #login form#lostpasswordform .forgetmenot label {}#login form .submit .button {height: auto;background-color: #ff9d00;font-size: 13px;width: 100%;height: 40px;padding: 0px 12px 2px 12px;border-width: 0px;box-shadow: 0px 1px 0px rgba(120,200,230,0.01);text-shadow: 0 -1px 1px #ff9d00,1px 0 1px #ff9d00,0 1px 1px #ff9d00,-1px 0 1px #ff9d00;}#login form .submit .button:hover, #login form .submit .button:focus {background-color: #ff9d00;}#login #backtoblog {display: none;}.login #nav, .login #nav a, .login #backtoblog a, .login .privacy-policy-page-link a {color: #ffffff;}.login #backtoblog a:hover, .login #nav a:hover, .login .privacy-policy-page-link a:hover {color: #dddddd;}/* Custom CSS for Material Template */
#login form#loginform .input,
#login form#registerform .input,
#login form#lostpasswordform .input {
	border-bottom: 1px solid #d2d2d2;
}

.bar {
	position: relative;
	display: block;
	width: 100%;
}

.bar:before, .bar:after {
	content: "";
	height: 2px; 
	width: 0;
	bottom: 15px; 
	position: absolute;
	background: #e91e63; 
	transition: all 0.2s ease;
}

.bar:before { left: 50%; }

.bar:after { right: 50%; }

input:focus ~ .bar:before, input:focus ~ .bar:after { width: 50%; }
#loginform label, #loginform b{
	font-family:Montserrat!important;
}
#loginform b{
	padding-bottom:20px;
	display: block;
}
</style>
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
		</head>
	<body class="login no-js login-action-login wp-core-ui  locale-en-us">
	<script type="text/javascript">
		document.body.className = document.body.className.replace('no-js','js');
	</script>
		<div id="login">
		<h1><a href="https://anerdsworld.com/">A Nerd&#039;s World</a></h1>
	
		<form name="loginform" id="loginform" action="https://anerdsworld.com/wp-login.php" method="post">
			<p>
				<label for="user_login">Username or Email Address</label>
				<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">Password</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input" value="" size="20" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Show password">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
						<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">Remember Me</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
									<input type="hidden" name="redirect_to" value="https://anerdsworld.com/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
								<a href="https://anerdsworld.com/wp-login.php?action=lostpassword">Lost your password?</a>
			</p>
					<script type="text/javascript">
			function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }		</script>
				<p id="backtoblog">
			<a href="https://anerdsworld.com/">&larr; Go to A Nerd&#039;s World</a>		</p>
			</div>
	<script>
// Custom JS for Material Template
function insertAfter( newNode, referenceNode ) {
    referenceNode.parentNode.insertBefore( newNode, referenceNode.nextSibling );
}

var inputFields = document.querySelectorAll( ".input" );

inputFields.forEach( ( field ) => {
	var bar = document.createElement("span");
		bar.setAttribute( "class", "bar" );
	insertAfter( bar, field );
});

var newItem = document.createElement("B");       // Create a <p> node
var textnode = document.createTextNode("Enter your provided login credentials:");  // Create a text node
newItem.appendChild(textnode);                    // Append the text to <p>

var list = document.getElementById("loginform").children[0];  // Get the <p> element to insert a new node
list.insertBefore(newItem, list.childNodes[0]); 
</script>
<script type='text/javascript' src='https://anerdsworld.com/wp-includes/js/jquery/jquery.min.js' defer ' id='jquery-core-js'></script>
<script type='text/javascript' src='https://anerdsworld.com/wp-includes/js/jquery/jquery-migrate.min.js' defer ' id='jquery-migrate-js'></script>
<script type='text/javascript' id='zxcvbn-async-js-extra'>
/* <![CDATA[ */
var _zxcvbnSettings = {"src":"https:\/\/anerdsworld.com\/wp-includes\/js\/zxcvbn.min.js"};
/* ]]> */
</script>
<script type='text/javascript' src='https://anerdsworld.com/wp-includes/js/zxcvbn-async.min.js' defer ' id='zxcvbn-async-js'></script>
<script type='text/javascript' src='https://anerdsworld.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js' defer ' id='regenerator-runtime-js'></script>
<script type='text/javascript' src='https://anerdsworld.com/wp-includes/js/dist/vendor/wp-polyfill.min.js' defer ' id='wp-polyfill-js'></script>
<script type='text/javascript' src='https://anerdsworld.com/wp-includes/js/dist/hooks.min.js' defer ' id='wp-hooks-js'></script>
<script type='text/javascript' src='https://anerdsworld.com/wp-includes/js/dist/i18n.min.js' defer ' id='wp-i18n-js'></script>
<script type='text/javascript' id='wp-i18n-js-after'>
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script type='text/javascript' id='password-strength-meter-js-extra'>
/* <![CDATA[ */
var pwsL10n = {"unknown":"Password strength unknown","short":"Very weak","bad":"Weak","good":"Medium","strong":"Strong","mismatch":"Mismatch"};
/* ]]> */
</script>
<script type='text/javascript' id='password-strength-meter-js-translations'>
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", { "locale_data": { "messages": { "": {} } } } );
</script>
<script type='text/javascript' src='https://anerdsworld.com/wp-admin/js/password-strength-meter.min.js' defer ' id='password-strength-meter-js'></script>
<script type='text/javascript' src='https://anerdsworld.com/wp-includes/js/underscore.min.js' defer ' id='underscore-js'></script>
<script type='text/javascript' id='wp-util-js-extra'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://anerdsworld.com/wp-includes/js/wp-util.min.js' defer ' id='wp-util-js'></script>
<script type='text/javascript' id='user-profile-js-extra'>
/* <![CDATA[ */
var userProfileL10n = {"user_id":"0","nonce":"aee35d7c4b"};
/* ]]> */
</script>
<script type='text/javascript' id='user-profile-js-translations'>
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", { "locale_data": { "messages": { "": {} } } } );
</script>
<script type='text/javascript' src='https://anerdsworld.com/wp-admin/js/user-profile.min.js' defer ' id='user-profile-js'></script>
	<div class="clear"></div>
	</body>
	</html>
	